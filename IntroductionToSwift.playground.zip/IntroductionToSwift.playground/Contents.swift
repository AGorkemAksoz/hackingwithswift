import UIKit

var str = "Hello, playground"

str="Goodbye"

var name = "Ali"


var age: Int = 28
var population: Int = 8_000_000

var multiLineBreakString: String = """
This goes
over multiple
lines
"""

var multiLineBreakString2: String = """
This goes \
over multiple\
lines
"""

print(multiLineBreakString)
print(multiLineBreakString2)

var pi: Double = 3.14
var awesome: Bool = true



var ageDescription = "Ali's age is \(age)"

// let can't change later
let taylor = "Swift"
